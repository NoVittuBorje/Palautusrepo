import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=35e49389"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=35e49389"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=35e49389"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const BlogForm = ({
  addBlog
}) => {
  _s();
  const [newblogTitle, setNewblogTitle] = useState("");
  const [newblogAuthor, setNewblogAuthor] = useState("");
  const [newblogUrl, setNewblogUrl] = useState("");
  const createBlog = (event) => {
    event.preventDefault();
    addBlog({
      "title": newblogTitle,
      "author": newblogAuthor,
      "url": newblogUrl
    });
    setNewblogAuthor("");
    setNewblogTitle("");
    setNewblogUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h3", { children: "Create new" }, void 0, false, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: createBlog, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "title:",
        /* @__PURE__ */ jsxDEV("input", { value: newblogTitle, "data-testid": "Title", onChange: (event) => setNewblogTitle(event.target.value) }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
          lineNumber: 26,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "author:",
        /* @__PURE__ */ jsxDEV("input", { value: newblogAuthor, "data-testid": "Author", onChange: (event) => setNewblogAuthor(event.target.value) }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
          lineNumber: 29,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "url:",
        /* @__PURE__ */ jsxDEV("input", { value: newblogUrl, "data-testid": "Url", onChange: (event) => setNewblogUrl(event.target.value) }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
          lineNumber: 32,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
        lineNumber: 31,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
      lineNumber: 24,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "YgQBv/9K4cU02pPhgyr0fjjBv8s=");
_c = BlogForm;
BlogForm.propTypes = {
  addBlog: PropTypes.func.isRequired
};
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJCTixTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0MsZUFBZTtBQUV0QixNQUFNQyxXQUFXQSxDQUFDO0FBQUEsRUFBRUM7QUFBUSxNQUFNO0FBQUFDLEtBQUE7QUFFaEMsUUFBTSxDQUFDQyxjQUFhQyxlQUFlLElBQUlOLFNBQVMsRUFBRTtBQUNsRCxRQUFNLENBQUNPLGVBQWNDLGdCQUFnQixJQUFJUixTQUFTLEVBQUU7QUFDcEQsUUFBTSxDQUFDUyxZQUFXQyxhQUFhLElBQUlWLFNBQVMsRUFBRTtBQUM5QyxRQUFNVyxhQUFjQyxXQUFVO0FBQzVCQSxVQUFNQyxlQUFlO0FBQ3JCVixZQUFRO0FBQUEsTUFDTixTQUFTRTtBQUFBQSxNQUNULFVBQVVFO0FBQUFBLE1BQ1YsT0FBT0U7QUFBQUEsSUFBVyxDQUFDO0FBQ3JCRCxxQkFBaUIsRUFBRTtBQUNuQkYsb0JBQWdCLEVBQUU7QUFDbEJJLGtCQUFjLEVBQUU7QUFBQSxFQUNsQjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFjO0FBQUEsSUFDZCx1QkFBQyxVQUFLLFVBQVVDLFlBQ2Q7QUFBQSw2QkFBQyxTQUFJO0FBQUE7QUFBQSxRQUNILHVCQUFDLFdBQU0sT0FBT04sY0FBYyxlQUFZLFNBQVEsVUFBVU8sV0FBU04sZ0JBQWdCTSxNQUFNRSxPQUFPQyxLQUFLLEtBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUc7QUFBQSxXQUR6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUk7QUFBQTtBQUFBLFFBQ0gsdUJBQUMsV0FBTSxPQUFPUixlQUFlLGVBQVksVUFBUyxVQUFVSyxXQUFTSixpQkFBaUJJLE1BQU1FLE9BQU9DLEtBQUssS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRztBQUFBLFdBRDVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSTtBQUFBO0FBQUEsUUFDSCx1QkFBQyxXQUFNLE9BQU9OLFlBQVksZUFBWSxPQUFNLFVBQVVHLFdBQVVGLGNBQWNFLE1BQU1FLE9BQU9DLEtBQUssS0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRztBQUFBLFdBRHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxTQVg5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FlQTtBQUNKO0FBQUNYLEdBakNLRixVQUFRO0FBQUFjLEtBQVJkO0FBa0NOQSxTQUFTZSxZQUFZO0FBQUEsRUFDbkJkLFNBQVFGLFVBQVVpQixLQUFLQztBQUV6QjtBQUVBLGVBQWVqQjtBQUFRLElBQUFjO0FBQUFJLGFBQUFKLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByb3BUeXBlcyIsIkJsb2dGb3JtIiwiYWRkQmxvZyIsIl9zIiwibmV3YmxvZ1RpdGxlIiwic2V0TmV3YmxvZ1RpdGxlIiwibmV3YmxvZ0F1dGhvciIsInNldE5ld2Jsb2dBdXRob3IiLCJuZXdibG9nVXJsIiwic2V0TmV3YmxvZ1VybCIsImNyZWF0ZUJsb2ciLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsInByb3BUeXBlcyIsImZ1bmMiLCJpc1JlcXVpcmVkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZ0Zvcm0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IEJsb2dGb3JtID0gKHsgYWRkQmxvZyB9KSA9PiB7XG5cbiAgY29uc3QgW25ld2Jsb2dUaXRsZSxzZXROZXdibG9nVGl0bGVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtuZXdibG9nQXV0aG9yLHNldE5ld2Jsb2dBdXRob3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtuZXdibG9nVXJsLHNldE5ld2Jsb2dVcmxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IGNyZWF0ZUJsb2cgPSAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgYWRkQmxvZyh7XG4gICAgICAndGl0bGUnOiBuZXdibG9nVGl0bGUsXG4gICAgICAnYXV0aG9yJzogbmV3YmxvZ0F1dGhvcixcbiAgICAgICd1cmwnOiBuZXdibG9nVXJsIH0pXG4gICAgc2V0TmV3YmxvZ0F1dGhvcignJylcbiAgICBzZXROZXdibG9nVGl0bGUoJycpXG4gICAgc2V0TmV3YmxvZ1VybCgnJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMz5DcmVhdGUgbmV3PC9oMz5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtjcmVhdGVCbG9nfT5cbiAgICAgICAgPGRpdj50aXRsZTpcbiAgICAgICAgICA8aW5wdXQgdmFsdWU9e25ld2Jsb2dUaXRsZX0gZGF0YS10ZXN0aWQ9J1RpdGxlJyBvbkNoYW5nZT17ZXZlbnQgPT4gc2V0TmV3YmxvZ1RpdGxlKGV2ZW50LnRhcmdldC52YWx1ZSl9Lz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+YXV0aG9yOlxuICAgICAgICAgIDxpbnB1dCB2YWx1ZT17bmV3YmxvZ0F1dGhvcn0gZGF0YS10ZXN0aWQ9J0F1dGhvcicgb25DaGFuZ2U9e2V2ZW50ID0+IHNldE5ld2Jsb2dBdXRob3IoZXZlbnQudGFyZ2V0LnZhbHVlKX0vPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj51cmw6XG4gICAgICAgICAgPGlucHV0IHZhbHVlPXtuZXdibG9nVXJsfSBkYXRhLXRlc3RpZD0nVXJsJyBvbkNoYW5nZT17ZXZlbnQgID0+IHNldE5ld2Jsb2dVcmwoZXZlbnQudGFyZ2V0LnZhbHVlKX0vPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5jcmVhdGU8L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj4pXG59XG5CbG9nRm9ybS5wcm9wVHlwZXMgPSB7XG4gIGFkZEJsb2c6UHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZFxuXG59XG5cbmV4cG9ydCBkZWZhdWx0IEJsb2dGb3JtIl0sImZpbGUiOiJDOi9Vc2Vycy90aXZpL0Rlc2t0b3AvUGFsYXV0dXNyZXBvLW1haW4vb3NhNS9ibG9nbGlzdC1mcm9udGVuZC1tYWluL3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9