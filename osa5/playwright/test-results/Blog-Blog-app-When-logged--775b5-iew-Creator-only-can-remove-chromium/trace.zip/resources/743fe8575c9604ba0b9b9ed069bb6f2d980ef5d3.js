import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/styles.css"
const __vite__css = ".message {\r\n    color:  green;\r\n    background: lightgrey;\r\n    font-size: 20px;\r\n    border-style: solid;\r\n    border-radius: 5px;\r\n    padding: 10px;\r\n    margin-bottom: 10px;\r\n  }\r\n.error {\r\n  color:  red;\r\n  background: lightgrey;\r\n  font-size: 20px;\r\n  border-style: solid;\r\n  border-radius: 5px;\r\n  padding: 10px;\r\n  margin-bottom: 10px;\r\n}\r\n.no-margin {\r\n  margin-bottom: 0;\r\n  margin-top: 0;\r\n}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))