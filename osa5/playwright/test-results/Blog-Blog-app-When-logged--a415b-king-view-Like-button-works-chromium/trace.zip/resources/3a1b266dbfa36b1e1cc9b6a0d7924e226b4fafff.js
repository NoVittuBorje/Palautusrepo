import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=35e49389"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=35e49389"; const useState = __vite__cjsImport3_react["useState"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"]; const forwardRef = __vite__cjsImport3_react["forwardRef"];
import blogService from "/src/services/blogs.js";
import __vite__cjsImport5_propTypes from "/node_modules/.vite/deps/prop-types.js?v=35e49389"; const PropTypes = __vite__cjsImport5_propTypes.__esModule ? __vite__cjsImport5_propTypes.default : __vite__cjsImport5_propTypes;
import Notification from "/src/components/Notification.jsx";
const Blog = _s(forwardRef(_c = _s((props, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const [deleted, setdeleted] = useState(false);
  const [Message, setMessage] = useState(null);
  const [Likes, setLikes] = useState(props.blog.likes);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const blogstyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const toggleVisibility = () => {
    setVisible(!visible);
  };
  useImperativeHandle(ref, () => {
    return {
      toggleVisibility
    };
  });
  const likeblog = () => {
    props.LikeBlog(props);
    setLikes(Likes + 1);
  };
  const DeleteBlog = () => {
    if (window.confirm("Remove blog " + props.blog.title + " by " + props.blog.author)) {
      blogService.deleteblog(props.blog.id).then((res) => {
        setdeleted(true);
      });
    }
  };
  const DelButton = () => {
    if (props.user.username === props.blog.user.username) {
      return /* @__PURE__ */ jsxDEV("button", { onClick: DeleteBlog, children: "remove" }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
        lineNumber: 46,
        columnNumber: 14
      }, this);
    } else {
      return null;
    }
  };
  if (!deleted) {
    return /* @__PURE__ */ jsxDEV("div", { style: blogstyle, "data-testid": "blogform", children: [
      /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: [
        props.blog.title,
        " ",
        props.blog.author,
        /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
          lineNumber: 55,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "togglableContent", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "no-margin", children: [
          props.blog.title,
          " ",
          props.blog.author,
          " ",
          /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "hide" }, void 0, false, {
            fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
            lineNumber: 59,
            columnNumber: 77
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
          lineNumber: 59,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("a", { href: props.blog.url, className: "no-margin", children: props.blog.url }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
          lineNumber: 60,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "no-margin", children: [
          "Likes ",
          Likes,
          " ",
          /* @__PURE__ */ jsxDEV("button", { placeholder: "like", onClick: likeblog, children: "like" }, void 0, false, {
            fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
            lineNumber: 61,
            columnNumber: 52
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
          lineNumber: 61,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "no-margin", children: props.blog.user.name }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
          lineNumber: 62,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(DelButton, {}, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
          lineNumber: 63,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
        lineNumber: 58,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
        lineNumber: 57,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx",
      lineNumber: 52,
      columnNumber: 12
    }, this);
  }
}, "6ThTwmk2ZFRvMBfnBFSxvQdy6yk=")), "6ThTwmk2ZFRvMBfnBFSxvQdy6yk=");
_c2 = Blog;
Blog.propTypes = {
  blog: PropTypes.object.isRequired,
  user: PropTypes.object.isRequired,
  buttonLabel: PropTypes.string.isRequired,
  LikeBlog: PropTypes.func.isRequired
};
Blog.displayName = "Blog";
export default Blog;
var _c, _c2;
$RefreshReg$(_c, "Blog$forwardRef");
$RefreshReg$(_c2, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNROzs7Ozs7Ozs7Ozs7Ozs7OztBQTNDUixTQUFTQSxVQUFVQyxxQkFBcUJDLGtCQUFrQjtBQUMxRCxPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsT0FBSUMsR0FBR0wsV0FBVU0sS0FBQUQsR0FBQyxDQUFDRSxPQUFPQyxRQUFRO0FBQUFILEtBQUE7QUFFdEMsUUFBTSxDQUFDSSxTQUFTQyxVQUFVLElBQUlaLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2UsU0FBU0MsVUFBVSxJQUFJaEIsU0FBUyxJQUFJO0FBRTNDLFFBQU0sQ0FBQ2lCLE9BQU1DLFFBQVEsSUFBSWxCLFNBQVNTLE1BQU1VLEtBQUtDLEtBQUs7QUFDbEQsUUFBTUMsa0JBQWtCO0FBQUEsSUFBRUMsU0FBU1gsVUFBVSxTQUFTO0FBQUEsRUFBRztBQUN6RCxRQUFNWSxrQkFBa0I7QUFBQSxJQUFFRCxTQUFTWCxVQUFVLEtBQUs7QUFBQSxFQUFPO0FBQ3pELFFBQU1hLFlBQVk7QUFBQSxJQUFDQyxZQUFXO0FBQUEsSUFBR0MsYUFBYTtBQUFBLElBQUVDLFFBQVE7QUFBQSxJQUFRQyxhQUFhO0FBQUEsSUFBR0MsY0FBYztBQUFBLEVBQUU7QUFDaEcsUUFBTUMsbUJBQW1CQSxNQUFNO0FBQzdCbEIsZUFBVyxDQUFDRCxPQUFPO0FBQUEsRUFDckI7QUFFQVYsc0JBQW9CUyxLQUFLLE1BQU07QUFDN0IsV0FBTztBQUFBLE1BQ0xvQjtBQUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTUMsV0FBVUEsTUFBTTtBQUNwQnRCLFVBQU11QixTQUFTdkIsS0FBSztBQUNwQlMsYUFBU0QsUUFBTyxDQUFDO0FBQUEsRUFHbkI7QUFDQSxRQUFNZ0IsYUFBYUEsTUFBTTtBQUN2QixRQUFJQyxPQUFPQyxRQUFRLGlCQUFpQjFCLE1BQU1VLEtBQUtpQixRQUFPLFNBQU8zQixNQUFNVSxLQUFLa0IsTUFBTSxHQUFHO0FBRS9FbEMsa0JBQVltQyxXQUFXN0IsTUFBTVUsS0FBS29CLEVBQUUsRUFBRUMsS0FBS0MsU0FBTztBQUNoRDNCLG1CQUFXLElBQUk7QUFBQSxNQUNqQixDQUFDO0FBQUEsSUFFSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEIsWUFBWUEsTUFBTTtBQUN0QixRQUFJakMsTUFBTWtDLEtBQUtDLGFBQWFuQyxNQUFNVSxLQUFLd0IsS0FBS0MsVUFBUztBQUNuRCxhQUNFLHVCQUFDLFlBQU8sU0FBU1gsWUFBWSxzQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLElBQ3BDLE9BQ0M7QUFBQyxhQUFPO0FBQUEsSUFBSTtBQUFBLEVBQ2xCO0FBRUEsTUFBSSxDQUFDcEIsU0FBUTtBQUNYLFdBQ0UsdUJBQUMsU0FBSSxPQUFPVyxXQUFXLGVBQVksWUFDakM7QUFBQSw2QkFBQyxTQUFJLE9BQU9ILGlCQUNUWjtBQUFBQSxjQUFNVSxLQUFLaUI7QUFBQUEsUUFBTTtBQUFBLFFBQUUzQixNQUFNVSxLQUFLa0I7QUFBQUEsUUFDL0IsdUJBQUMsWUFBTyxTQUFTUCxrQkFBbUJyQixnQkFBTW9DLGVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxXQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQ0MsaUNBQUMsU0FBSSxPQUFPdEIsaUJBQWtCLFdBQVUsb0JBQ3RDO0FBQUEsK0JBQUMsT0FBRSxXQUFVLGFBQWFkO0FBQUFBLGdCQUFNVSxLQUFLaUI7QUFBQUEsVUFBTTtBQUFBLFVBQUUzQixNQUFNVSxLQUFLa0I7QUFBQUEsVUFBTztBQUFBLFVBQUMsdUJBQUMsWUFBTyxTQUFTUCxrQkFBa0Isb0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVDO0FBQUEsYUFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnSDtBQUFBLFFBQ2hILHVCQUFDLE9BQUUsTUFBTXJCLE1BQU1VLEtBQUsyQixLQUFLLFdBQVUsYUFBYXJDLGdCQUFNVSxLQUFLMkIsT0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFFBQy9ELHVCQUFDLE9BQUUsV0FBVSxhQUFZO0FBQUE7QUFBQSxVQUFPN0I7QUFBQUEsVUFBTTtBQUFBLFVBQUMsdUJBQUMsWUFBTyxhQUFZLFFBQU8sU0FBU2MsVUFBVSxvQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxhQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtHO0FBQUEsUUFDbEcsdUJBQUMsT0FBRSxXQUFVLGFBQWF0QixnQkFBTVUsS0FBS3dCLEtBQUtJLFFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUMvQyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVTtBQUFBLFdBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUE7QUFBQSxFQUNEO0FBQ0wsR0FBQyxrQ0FBQztBQUFBQyxNQTlESTFDO0FBK0ROQSxLQUFLMkMsWUFBWTtBQUFBLEVBQ2Y5QixNQUFLZixVQUFVOEMsT0FBT0M7QUFBQUEsRUFDdEJSLE1BQUt2QyxVQUFVOEMsT0FBT0M7QUFBQUEsRUFDdEJOLGFBQVl6QyxVQUFVZ0QsT0FBT0Q7QUFBQUEsRUFDN0JuQixVQUFTNUIsVUFBVWlELEtBQUtGO0FBRTFCO0FBQ0E3QyxLQUFLZ0QsY0FBYztBQUNuQixlQUFlaEQ7QUFBSSxJQUFBRSxJQUFBd0M7QUFBQU8sYUFBQS9DLElBQUE7QUFBQStDLGFBQUFQLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUltcGVyYXRpdmVIYW5kbGUiLCJmb3J3YXJkUmVmIiwiYmxvZ1NlcnZpY2UiLCJQcm9wVHlwZXMiLCJOb3RpZmljYXRpb24iLCJCbG9nIiwiX3MiLCJfYyIsInByb3BzIiwicmVmIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJkZWxldGVkIiwic2V0ZGVsZXRlZCIsIk1lc3NhZ2UiLCJzZXRNZXNzYWdlIiwiTGlrZXMiLCJzZXRMaWtlcyIsImJsb2ciLCJsaWtlcyIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJibG9nc3R5bGUiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJib3JkZXIiLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsInRvZ2dsZVZpc2liaWxpdHkiLCJsaWtlYmxvZyIsIkxpa2VCbG9nIiwiRGVsZXRlQmxvZyIsIndpbmRvdyIsImNvbmZpcm0iLCJ0aXRsZSIsImF1dGhvciIsImRlbGV0ZWJsb2ciLCJpZCIsInRoZW4iLCJyZXMiLCJEZWxCdXR0b24iLCJ1c2VyIiwidXNlcm5hbWUiLCJidXR0b25MYWJlbCIsInVybCIsIm5hbWUiLCJfYzIiLCJwcm9wVHlwZXMiLCJvYmplY3QiLCJpc1JlcXVpcmVkIiwic3RyaW5nIiwiZnVuYyIsImRpc3BsYXlOYW1lIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmxvZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgLHVzZUltcGVyYXRpdmVIYW5kbGUsIGZvcndhcmRSZWYgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9Ob3RpZmljYXRpb24nXG5cbmNvbnN0IEJsb2cgPSBmb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG4gIFxuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2RlbGV0ZWQsIHNldGRlbGV0ZWRdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtNZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgY29uc3QgW0xpa2VzLHNldExpa2VzXSA9IHVzZVN0YXRlKHByb3BzLmJsb2cubGlrZXMpXG4gIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICdub25lJyA6ICcnIH1cbiAgY29uc3Qgc2hvd1doZW5WaXNpYmxlID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJycgOiAnbm9uZScgfVxuICBjb25zdCBibG9nc3R5bGUgPSB7cGFkZGluZ1RvcDoxMCxwYWRkaW5nTGVmdDogMixib3JkZXI6ICdzb2xpZCcsYm9yZGVyV2lkdGg6IDEsIG1hcmdpbkJvdHRvbTogNSB9XG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiB7XG4gICAgc2V0VmlzaWJsZSghdmlzaWJsZSlcbiAgfVxuXG4gIHVzZUltcGVyYXRpdmVIYW5kbGUocmVmLCAoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRvZ2dsZVZpc2liaWxpdHlcbiAgICB9XG4gIH0pXG4gIGNvbnN0IGxpa2VibG9nPSAoKSA9PiB7XG4gICAgcHJvcHMuTGlrZUJsb2cocHJvcHMpXG4gICAgc2V0TGlrZXMoTGlrZXMgKzEpXG4gICAgXG5cbiAgfVxuICBjb25zdCBEZWxldGVCbG9nID0gKCkgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybSgnUmVtb3ZlIGJsb2cgJyArIHByb3BzLmJsb2cudGl0bGUgKycgYnkgJytwcm9wcy5ibG9nLmF1dGhvcikpIHtcbiAgICAgIFxuICAgICAgYmxvZ1NlcnZpY2UuZGVsZXRlYmxvZyhwcm9wcy5ibG9nLmlkKS50aGVuKHJlcyA9PiB7XG4gICAgICAgIHNldGRlbGV0ZWQodHJ1ZSlcbiAgICAgIH0pXG4gICAgICBcbiAgICB9XG4gIH1cblxuICBjb25zdCBEZWxCdXR0b24gPSAoKSA9PiB7XG4gICAgaWYgKHByb3BzLnVzZXIudXNlcm5hbWUgPT09IHByb3BzLmJsb2cudXNlci51c2VybmFtZSl7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e0RlbGV0ZUJsb2d9PnJlbW92ZTwvYnV0dG9uPlxuICAgICAgKX1cbiAgICBlbHNle3JldHVybiBudWxsfVxuICB9XG5cbiAgaWYgKCFkZWxldGVkKXtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBzdHlsZT17YmxvZ3N0eWxlfSBkYXRhLXRlc3RpZD0nYmxvZ2Zvcm0nPlxuICAgICAgICA8ZGl2IHN0eWxlPXtoaWRlV2hlblZpc2libGV9PlxuICAgICAgICAgIHtwcm9wcy5ibG9nLnRpdGxlfSB7cHJvcHMuYmxvZy5hdXRob3J9XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT57cHJvcHMuYnV0dG9uTGFiZWx9PC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3Nob3dXaGVuVmlzaWJsZSB9IGNsYXNzTmFtZT1cInRvZ2dsYWJsZUNvbnRlbnRcIj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0nbm8tbWFyZ2luJz57cHJvcHMuYmxvZy50aXRsZX0ge3Byb3BzLmJsb2cuYXV0aG9yfSA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9PmhpZGU8L2J1dHRvbj48L3A+XG4gICAgICAgICAgICA8YSBocmVmPXtwcm9wcy5ibG9nLnVybH0gY2xhc3NOYW1lPSduby1tYXJnaW4nPntwcm9wcy5ibG9nLnVybH08L2E+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9J25vLW1hcmdpbic+TGlrZXMge0xpa2VzfSA8YnV0dG9uIHBsYWNlaG9sZGVyPSdsaWtlJyBvbkNsaWNrPXtsaWtlYmxvZ30+bGlrZTwvYnV0dG9uPjwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0nbm8tbWFyZ2luJz57cHJvcHMuYmxvZy51c2VyLm5hbWV9PC9wPlxuICAgICAgICAgICAgPERlbEJ1dHRvbiAvPlxuXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKX1cbn0pXG5CbG9nLnByb3BUeXBlcyA9IHtcbiAgYmxvZzpQcm9wVHlwZXMub2JqZWN0LmlzUmVxdWlyZWQsXG4gIHVzZXI6UHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkLFxuICBidXR0b25MYWJlbDpQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXG4gIExpa2VCbG9nOlByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWRcblxufVxuQmxvZy5kaXNwbGF5TmFtZSA9ICdCbG9nJ1xuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiQzovVXNlcnMvdGl2aS9EZXNrdG9wL1BhbGF1dHVzcmVwby1tYWluL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQtbWFpbi9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9