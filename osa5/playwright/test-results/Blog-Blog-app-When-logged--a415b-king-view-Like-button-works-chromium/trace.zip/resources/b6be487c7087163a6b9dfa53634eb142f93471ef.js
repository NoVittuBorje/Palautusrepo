import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=35e49389"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=35e49389"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1730115557167";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/loginService.js";
import Notification from "/src/components/Notification.jsx";
import ErrorNotification from "/src/components/ErrorNotification.jsx";
import "/src/styles.css";
import Togglable from "/src/components/Togglable.jsx";
import BlogForm from "/src/components/BlogForm.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const blogFormRef = useRef();
  const blogref = useRef();
  const [errorMessage, setErrorMessage] = useState(null);
  const [Message, setMessage] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    blogService.getAll().then((blogs2) => {
      blogs2.sort((a, b) => b.likes - a.likes);
      setBlogs(blogs2);
    });
  }, []);
  const loginForm = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Log in to app" }, void 0, false, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { type: "text", value: username, name: "Username", "data-testid": "username", onChange: ({
          target
        }) => setUsername(target.value) }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
          lineNumber: 40,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV("input", { type: "password", value: password, name: "Password", "data-testid": "password", onChange: ({
          target
        }) => setPassword(target.value) }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
          lineNumber: 46,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 44,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
    lineNumber: 35,
    columnNumber: 27
  }, this);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.log(exception.message);
      setErrorMessage("wrong credentials");
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    }
  };
  const LikeBlog = (props) => {
    props.blog.likes = props.blog.likes + 1;
    blogService.update(props.blog.id, props.blog).then((returnedblog) => {
      blogService.getAll().then((blogs2) => {
        blogs2.sort((a, b) => b.likes - a.likes);
        setBlogs(blogs2);
      });
    }).catch((error) => console.log(error));
  };
  const addBlog = (BlogObject) => {
    blogService.create(BlogObject).then((blog) => {
      blogService.getAll().then((blogs2) => {
        blogs2.sort((a, b) => b.likes - a.likes);
        setBlogs(blogs2);
      });
      setMessage(`a new blog ${blog.title} by ${blog.author} added`);
      setTimeout(() => {
        setMessage(null);
      }, 5e3);
    }).catch((exception) => {
      console.log(exception.message);
      setErrorMessage(exception.message);
      setTimeout(() => {
        setErrorMessage(null);
      }, 5e3);
    });
    blogFormRef.current.toggleVisibility();
  };
  const logOut = () => {
    setUser(null);
    window.localStorage.removeItem("loggedUser");
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(Notification, { message: Message }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 107,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ErrorNotification, { message: errorMessage }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 108,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: loginForm() }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 109,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
      lineNumber: 106,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "blogs" }, void 0, false, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: Message }, void 0, false, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ErrorNotification, { message: errorMessage }, void 0, false, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
      lineNumber: 117,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        user.name,
        " logged in ",
        /* @__PURE__ */ jsxDEV("button", { onClick: logOut, children: "logout" }, void 0, false, {
          fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
          lineNumber: 119,
          columnNumber: 34
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 119,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { addBlog }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 122,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, ref: blogref, LikeBlog, buttonLabel: "view", user }, blog.id, false, {
        fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
        lineNumber: 124,
        columnNumber: 28
      }, this))
    ] }, void 0, true, {
      fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
      lineNumber: 118,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx",
    lineNumber: 114,
    columnNumber: 10
  }, this);
};
_s(App, "Q1sc0IC0RPwI6nzfSnvNgrMmwkc=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/tivi/Desktop/Palautusrepo-main/osa5/bloglist-frontend-main/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU87QUFDUCxPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGNBQWM7QUFHckIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFFckMsUUFBTWMsY0FBY1osT0FBTztBQUMzQixRQUFNYSxVQUFVYixPQUFPO0FBRXZCLFFBQU0sQ0FBQ2MsY0FBY0MsZUFBZSxJQUFJakIsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ2tCLFNBQVNDLFVBQVUsSUFBSW5CLFNBQVMsSUFBSTtBQUUzQyxRQUFNLENBQUNvQixVQUFVQyxXQUFXLElBQUlyQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDc0IsVUFBVUMsV0FBVyxJQUFJdkIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3dCLE1BQU1DLE9BQU8sSUFBSXpCLFNBQVMsSUFBSTtBQUVyQ0MsWUFBVSxNQUFNO0FBQ2QsVUFBTXlCLGlCQUFpQkMsT0FBT0MsYUFBYUMsUUFBUSxZQUFZO0FBQy9ELFFBQUlILGdCQUFnQjtBQUNsQixZQUFNRixRQUFPTSxLQUFLQyxNQUFNTCxjQUFjO0FBQ3RDRCxjQUFRRCxLQUFJO0FBQ1pwQixrQkFBWTRCLFNBQVNSLE1BQUtTLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUxoQyxZQUFVLE1BQU07QUFDZEcsZ0JBQVk4QixPQUFPLEVBQUVDLEtBQUt2QixZQUFTO0FBQ2pDQSxhQUFNd0IsS0FBSyxDQUFDQyxHQUFFQyxNQUFNQSxFQUFFQyxRQUFRRixFQUFFRSxLQUFLO0FBQ3JDMUIsZUFBVUQsTUFBTTtBQUFBLElBQ2xCLENBRUE7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU00QixZQUFZQSxNQUNoQix1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCO0FBQUEsSUFDakIsdUJBQUMsVUFBSyxVQUFVQyxhQUNkO0FBQUEsNkJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRix1QkFBQyxXQUNDLE1BQUssUUFDTCxPQUFPckIsVUFDUCxNQUFLLFlBQ0wsZUFBWSxZQUNaLFVBQVUsQ0FBQztBQUFBLFVBQUVzQjtBQUFBQSxRQUFPLE1BQU1yQixZQUFZcUIsT0FBT0MsS0FBSyxLQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS3NEO0FBQUEsV0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsTUFBSyxZQUNMLE9BQU9yQixVQUNQLE1BQUssWUFDTCxlQUFZLFlBQ1osVUFBVSxDQUFDO0FBQUEsVUFBRW9CO0FBQUFBLFFBQU8sTUFBTW5CLFlBQVltQixPQUFPQyxLQUFLLEtBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLc0Q7QUFBQSxXQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCO0FBQUEsU0FyQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxPQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBR0YsUUFBTUYsY0FBYyxPQUFPRyxVQUFVO0FBQ25DQSxVQUFNQyxlQUFlO0FBQ3JCLFFBQUk7QUFDRixZQUFNckIsUUFBTyxNQUFNbkIsYUFBYXlDLE1BQU07QUFBQSxRQUNwQzFCO0FBQUFBLFFBQVVFO0FBQUFBLE1BQ1osQ0FBQztBQUNESyxhQUFPQyxhQUFhbUIsUUFDbEIsY0FBY2pCLEtBQUtrQixVQUFVeEIsS0FBSSxDQUNuQztBQUNBcEIsa0JBQVk0QixTQUFTUixNQUFLUyxLQUFLO0FBQy9CUixjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVMwQixXQUFXO0FBQ2xCQyxjQUFRQyxJQUFJRixVQUFVRyxPQUFPO0FBQzdCbkMsc0JBQWdCLG1CQUFtQjtBQUNuQ29DLGlCQUFXLE1BQU07QUFDZnBDLHdCQUFnQixJQUFJO0FBQUEsTUFDdEIsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxRQUFNcUMsV0FBV0MsV0FBVTtBQUV6QkEsVUFBTUMsS0FBS2pCLFFBQVFnQixNQUFNQyxLQUFLakIsUUFBUTtBQUN0Q25DLGdCQUFZcUQsT0FBT0YsTUFBTUMsS0FBS0UsSUFBR0gsTUFBTUMsSUFBSSxFQUFFckIsS0FBS3dCLGtCQUFnQjtBQUNoRXZELGtCQUFZOEIsT0FBTyxFQUFFQyxLQUFLdkIsWUFBUztBQUNqQ0EsZUFBTXdCLEtBQUssQ0FBQ0MsR0FBRUMsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSztBQUNyQzFCLGlCQUFVRCxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFDcEIsQ0FBQyxFQUFFZ0QsTUFBTUMsV0FBU1gsUUFBUUMsSUFBSVUsS0FBSyxDQUFDO0FBQUEsRUFFeEM7QUFDQSxRQUFNQyxVQUFXQyxnQkFBZTtBQUM5QjNELGdCQUFZNEQsT0FBT0QsVUFBVSxFQUFFNUIsS0FBS3FCLFVBQVE7QUFDMUNwRCxrQkFBWThCLE9BQU8sRUFBRUMsS0FBS3ZCLFlBQVM7QUFDakNBLGVBQU13QixLQUFLLENBQUNDLEdBQUVDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUs7QUFDckMxQixpQkFBVUQsTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUNwQk8saUJBQVksY0FBYXFDLEtBQUtTLEtBQU0sT0FBTVQsS0FBS1UsTUFBTyxRQUFPO0FBQzdEYixpQkFBVyxNQUFNO0FBQ2ZsQyxtQkFBVyxJQUFJO0FBQUEsTUFDakIsR0FBRyxHQUFJO0FBQUEsSUFDVCxDQUFDLEVBQUV5QyxNQUFNWCxlQUFhO0FBQ3BCQyxjQUFRQyxJQUFJRixVQUFVRyxPQUFPO0FBQzdCbkMsc0JBQWdCZ0MsVUFBVUcsT0FBTztBQUNqQ0MsaUJBQVcsTUFBTTtBQUNmcEMsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixHQUFHLEdBQUk7QUFBQSxJQUFDLENBQUM7QUFDWEgsZ0JBQVlxRCxRQUFRQyxpQkFBaUI7QUFBQSxFQUN2QztBQUVBLFFBQU1DLFNBQVNBLE1BQU07QUFDbkI1QyxZQUFRLElBQUk7QUFDWkUsV0FBT0MsYUFBYTBDLFdBQVcsWUFBWTtBQUFBLEVBQzdDO0FBRUEsTUFBSTlDLFNBQVMsTUFBTTtBQUNqQixXQUNFLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxnQkFBYSxTQUFTTixXQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDL0IsdUJBQUMscUJBQWtCLFNBQVNGLGdCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDO0FBQUEsTUFDekMsdUJBQUMsU0FDRXdCLG9CQUFVLEtBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLGdCQUFhLFNBQVN0QixXQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStCO0FBQUEsSUFDL0IsdUJBQUMscUJBQWtCLFNBQVNGLGdCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDO0FBQUEsSUFDekMsdUJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUdRO0FBQUFBLGFBQUsrQztBQUFBQSxRQUFLO0FBQUEsUUFBVyx1QkFBQyxZQUFPLFNBQVNGLFFBQVEsc0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxXQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFFakUsdUJBQUMsYUFBVSxhQUFZLG1CQUFrQixLQUFLdkQsYUFDNUMsaUNBQUMsWUFBUyxXQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkIsS0FEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ0YsTUFBTTRELElBQUloQixVQUNULHVCQUFDLFFBQW9CLE1BQVksS0FBS3pDLFNBQVMsVUFBb0IsYUFBWSxRQUFPLFFBQTNFeUMsS0FBS0UsSUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRyxDQUFHO0FBQUEsU0FQeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFJSjtBQUFDL0MsR0FoSktELEtBQUc7QUFBQStELEtBQUgvRDtBQWtKTixlQUFlQTtBQUFHLElBQUErRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJCbG9nIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJOb3RpZmljYXRpb24iLCJFcnJvck5vdGlmaWNhdGlvbiIsIlRvZ2dsYWJsZSIsIkJsb2dGb3JtIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwiYmxvZ0Zvcm1SZWYiLCJibG9ncmVmIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwiTWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibG9nZ2VkVXNlckpTT04iLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImdldEFsbCIsInRoZW4iLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsImxvZ2luRm9ybSIsImhhbmRsZUxvZ2luIiwidGFyZ2V0IiwidmFsdWUiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwibG9naW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiZXhjZXB0aW9uIiwiY29uc29sZSIsImxvZyIsIm1lc3NhZ2UiLCJzZXRUaW1lb3V0IiwiTGlrZUJsb2ciLCJwcm9wcyIsImJsb2ciLCJ1cGRhdGUiLCJpZCIsInJldHVybmVkYmxvZyIsImNhdGNoIiwiZXJyb3IiLCJhZGRCbG9nIiwiQmxvZ09iamVjdCIsImNyZWF0ZSIsInRpdGxlIiwiYXV0aG9yIiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJsb2dPdXQiLCJyZW1vdmVJdGVtIiwibmFtZSIsIm1hcCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0ICx1c2VSZWYgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBCbG9nIGZyb20gJy4vY29tcG9uZW50cy9CbG9nJ1xuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvYmxvZ3MnXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW5TZXJ2aWNlJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uJ1xuaW1wb3J0IEVycm9yTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9FcnJvck5vdGlmaWNhdGlvbidcbmltcG9ydCAnLi9zdHlsZXMuY3NzJ1xuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL2NvbXBvbmVudHMvVG9nZ2xhYmxlJ1xuaW1wb3J0IEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9CbG9nRm9ybSdcblxuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXG5cbiAgY29uc3QgYmxvZ0Zvcm1SZWYgPSB1c2VSZWYoKVxuICBjb25zdCBibG9ncmVmID0gdXNlUmVmKClcblxuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW01lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcblxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgbG9nZ2VkVXNlckpTT04gPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvZ2dlZFVzZXInKVxuICAgIGlmIChsb2dnZWRVc2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+IHtcbiAgICAgIGJsb2dzLnNvcnQoKGEsYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXG4gICAgICBzZXRCbG9ncyggYmxvZ3MgKVxuICAgIH1cblxuICAgIClcbiAgfSwgW10pXG5cbiAgY29uc3QgbG9naW5Gb3JtID0gKCkgPT4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+TG9nIGluIHRvIGFwcDwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgICA8ZGl2PlxuICAgICAgdXNlcm5hbWVcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cbiAgICAgICAgICAgIG5hbWU9XCJVc2VybmFtZVwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ndXNlcm5hbWUnXG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICBwYXNzd29yZFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG5hbWU9XCJQYXNzd29yZFwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ncGFzc3dvcmQnXG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmxvZ2luPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XG4gICAgICAgIHVzZXJuYW1lLCBwYXNzd29yZCxcbiAgICAgIH0pXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICdsb2dnZWRVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcilcbiAgICAgIClcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgY29uc29sZS5sb2coZXhjZXB0aW9uLm1lc3NhZ2UpXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ3dyb25nIGNyZWRlbnRpYWxzJylcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcbiAgICAgIH0sIDUwMDApXG4gICAgfVxuICB9XG4gIGNvbnN0IExpa2VCbG9nPSAocHJvcHMpID0+IHtcbiAgICBcbiAgICBwcm9wcy5ibG9nLmxpa2VzID0gcHJvcHMuYmxvZy5saWtlcyArIDFcbiAgICBibG9nU2VydmljZS51cGRhdGUocHJvcHMuYmxvZy5pZCxwcm9wcy5ibG9nKS50aGVuKHJldHVybmVkYmxvZyA9PiB7XG4gICAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+IHtcbiAgICAgICAgYmxvZ3Muc29ydCgoYSxiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcbiAgICAgICAgc2V0QmxvZ3MoIGJsb2dzICl9KVxuICAgICAgfSkuY2F0Y2goZXJyb3IgPT4gY29uc29sZS5sb2coZXJyb3IpKVxuICAgICAgXG4gIH1cbiAgY29uc3QgYWRkQmxvZyA9IChCbG9nT2JqZWN0KSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UuY3JlYXRlKEJsb2dPYmplY3QpLnRoZW4oYmxvZyA9PiB7XG4gICAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+IHtcbiAgICAgICAgYmxvZ3Muc29ydCgoYSxiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcbiAgICAgICAgc2V0QmxvZ3MoIGJsb2dzICl9KVxuICAgICAgc2V0TWVzc2FnZShgYSBuZXcgYmxvZyAke2Jsb2cudGl0bGV9IGJ5ICR7YmxvZy5hdXRob3J9IGFkZGVkYClcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRNZXNzYWdlKG51bGwpXG4gICAgICB9LCA1MDAwKVxuICAgIH0pLmNhdGNoKGV4Y2VwdGlvbiA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhleGNlcHRpb24ubWVzc2FnZSlcbiAgICAgIHNldEVycm9yTWVzc2FnZShleGNlcHRpb24ubWVzc2FnZSlcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRFcnJvck1lc3NhZ2UobnVsbClcbiAgICAgIH0sIDUwMDApfSlcbiAgICBibG9nRm9ybVJlZi5jdXJyZW50LnRvZ2dsZVZpc2liaWxpdHkoKVxuICB9XG5cbiAgY29uc3QgbG9nT3V0ID0gKCkgPT4ge1xuICAgIHNldFVzZXIobnVsbClcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2xvZ2dlZFVzZXInKVxuICB9XG5cbiAgaWYgKHVzZXIgPT09IG51bGwpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdj5cbiAgICAgICAgPE5vdGlmaWNhdGlvbiBtZXNzYWdlPXtNZXNzYWdlfSAvPlxuICAgICAgICA8RXJyb3JOb3RpZmljYXRpb24gbWVzc2FnZT17ZXJyb3JNZXNzYWdlfSAvPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIHtsb2dpbkZvcm0oKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDE+YmxvZ3M8L2gxPlxuICAgICAgPE5vdGlmaWNhdGlvbiBtZXNzYWdlPXtNZXNzYWdlfSAvPlxuICAgICAgPEVycm9yTm90aWZpY2F0aW9uIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZX0gLz5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxwPnt1c2VyLm5hbWV9IGxvZ2dlZCBpbiA8YnV0dG9uIG9uQ2xpY2s9e2xvZ091dH0+bG9nb3V0PC9idXR0b24+PC9wPlxuXG4gICAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9XCJDcmVhdGUgbmV3IGJsb2dcIiByZWY9e2Jsb2dGb3JtUmVmfT5cbiAgICAgICAgICA8QmxvZ0Zvcm0gYWRkQmxvZz17YWRkQmxvZ30vPlxuICAgICAgICA8L1RvZ2dsYWJsZT5cbiAgICAgICAge2Jsb2dzLm1hcChibG9nID0+XG4gICAgICAgICAgPEJsb2cga2V5PXtibG9nLmlkfSAgYmxvZz17YmxvZ30gcmVmPXtibG9ncmVmfSBMaWtlQmxvZz17TGlrZUJsb2d9IGJ1dHRvbkxhYmVsPVwidmlld1wiIHVzZXI9e3VzZXJ9IC8+KX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG5cblxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6IkM6L1VzZXJzL3RpdmkvRGVza3RvcC9QYWxhdXR1c3JlcG8tbWFpbi9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kLW1haW4vc3JjL0FwcC5qc3gifQ==