import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=35e49389";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=35e49389";
export default require_react();
//# sourceMappingURL=react.js.map
