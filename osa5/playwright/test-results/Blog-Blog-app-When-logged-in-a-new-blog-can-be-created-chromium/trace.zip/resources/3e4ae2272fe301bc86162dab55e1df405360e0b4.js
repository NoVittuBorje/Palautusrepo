import axios from "/node_modules/.vite/deps/axios.js?v=35e49389"
const baseUrl = 'http://localhost:3003/api/login'

const login = async credentials => {
  const response = await axios.post(baseUrl, credentials)
  return response.data
}

export default { login }